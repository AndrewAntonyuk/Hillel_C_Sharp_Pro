﻿namespace ThirdLesson.someStandardInterfaces
{
    // Итераторы и оператор yield
    public static class Example7
    {
        public static void StartTest()
        {

        }
    }
}

﻿namespace ThirdLesson.someStandardInterfaces
{
    // Интерфейсы IEnumerable и IEnumerator
    public static class Example6
    {
        public static void StartTest()
        {

        }
    }
}

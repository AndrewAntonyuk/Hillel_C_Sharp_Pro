﻿// JavaScript source code
alert('Привет, мир!');
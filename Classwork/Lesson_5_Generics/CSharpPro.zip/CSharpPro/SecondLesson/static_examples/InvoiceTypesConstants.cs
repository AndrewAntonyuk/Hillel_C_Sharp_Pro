﻿namespace SecondLesson.static_examples
{
    public static class InvoiceTypes
    {
        public const string Urgent = "UrgentInvoice";

        public const string Simple = "SimpleInvoice";
    }
}

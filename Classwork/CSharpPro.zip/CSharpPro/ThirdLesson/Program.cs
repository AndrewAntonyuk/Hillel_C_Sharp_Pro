﻿using ThirdLesson.abstractClasses;
using ThirdLesson.interfaces;
using ThirdLesson.objAndMethods;
using ThirdLesson.someStandardInterfaces;
using ThirdLesson.someStandardInterfacesV2;

namespace ThirdLesson
{
    public static class Program
    {
        public static void Main()
        {
            // Example1.StartTest();
            // Example2.StartTest();
            // Example3.StartTest();
            // Example4.StartTest();
            // Example5.StartTest();
            // Example6.StartTest();
            // Example7.StartTest();
        }
    }
}
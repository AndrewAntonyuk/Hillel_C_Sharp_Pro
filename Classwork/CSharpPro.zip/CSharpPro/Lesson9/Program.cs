﻿namespace Lesson9
{
    public static class Program
    {
        public static void Main(string[] args)
        {

        }
    }
}
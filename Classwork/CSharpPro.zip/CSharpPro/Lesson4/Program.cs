﻿namespace Lesson4
{
    public static class Program
    {
        public static void Main()
        {
            Example1.StartTest();
            // Example2.StartTest();

        }
    }
}
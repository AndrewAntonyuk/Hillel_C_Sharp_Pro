﻿using Lesson5.v2;

namespace Lesson5
{
    public static class Program
    {
        public static void Main()
        {
            // Example1.Test();
            Example2.Test();
        }
    }
}
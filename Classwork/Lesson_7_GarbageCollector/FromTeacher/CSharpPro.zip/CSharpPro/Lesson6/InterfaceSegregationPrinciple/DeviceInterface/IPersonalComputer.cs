﻿namespace InterfaceSegregationPrinciple.DeviceInterface
{
    interface IPersonalComputer
    {
        string CoolingSystem { get; set; }

        string CaseFormFactor { get; set; }
    }
}

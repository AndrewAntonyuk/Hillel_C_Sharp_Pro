﻿namespace DependencyInversionPrinciple.MessageInterface
{
    public interface IMessage
    {
        string SendMessage();
    }
}

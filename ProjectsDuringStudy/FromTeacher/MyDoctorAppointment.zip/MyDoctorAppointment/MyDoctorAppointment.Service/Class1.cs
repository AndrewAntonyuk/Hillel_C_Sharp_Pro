﻿namespace MyDoctorAppointment.Service
{
    public class Class1
    {

    }
}
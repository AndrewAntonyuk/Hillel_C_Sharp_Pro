﻿namespace MyDoctorAppointment.Data.Configuration
{
    public static class Constants
    {
        public const string AppSettingsPath = "C:\\Users\\admin\\source\\repos\\MyDoctorAppointment\\DoctorAppointment.Data\\Configuration\\appsettings.json";
    }
}
